module.exports = [
    'azkafajril473@gmail.com',
    'admin2@email.com'
  ];